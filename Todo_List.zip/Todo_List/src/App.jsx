import "./App.css";
import { Form } from "./Components/Form/Form";

function App() {
  console.log("hi")
  return (
    <>
      <Form />
    </>
  );
}

export default App;
